#ifndef FUNCTION_H
#define FUNCTION_H
#include <stdio.h>
void printName();

#endif