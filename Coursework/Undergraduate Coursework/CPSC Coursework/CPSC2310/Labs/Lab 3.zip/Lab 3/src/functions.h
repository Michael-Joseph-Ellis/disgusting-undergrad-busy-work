#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include<stdio.h>
#include<assert.h>

void printMonths(FILE*);

#endif