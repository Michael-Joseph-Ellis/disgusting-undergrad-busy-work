GRADE_MAP = {0: "A", 1: "B", 2: "C", 3: "D", 4: "F"}
GRADE_ORDER = ["A", "B", "C", "D", "F"]
